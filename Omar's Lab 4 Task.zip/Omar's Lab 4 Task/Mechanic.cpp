#include <iostream>
using namespace std;

class Mechanic {
private:
    string name;
    double hourly_rate;
    string location;
public:
    Mechanic() {
        name = "";
        hourly_rate = 0.0;
        location = "";
    }
    ~Mechanic() {

    }
    void setName(string n) {
        name = n;
    }
    string getName() const {
        return name;
    }
    void setHourlyRate(float hr) {
        hourly_rate = hr;
    }
    double getHourlyRate() const {
        return hourly_rate;
    }
    void setLocation(string l) {
        location = l;
    }
    string getLocation() const {
        return location;
    }
    double Pay(float hours) const {
        return hours * hourly_rate;
    }
};


int main() {

    Mechanic m;
    m.setName("Omar");
    m.setLocation("New Cairo");
    m.setHourlyRate(2.5);

    cout << "The Payment For Mechanic " << m.getName() << " In " << m.getLocation() << " Is $" << m.Pay(15.5) << endl;

    return 0;
}
