#include <iostream>
using namespace std;

class Employee {
private:
    string name;
    int age;
    float salary;
    int years_of_experience;
public:
    Employee() {
        name = "";
        age = 0;
        salary = 0.0;
        years_of_experience = 0;
    }
    ~Employee() {

    }
    void setName(string n) {
        name = n;
    }
    string getName() {
        return name;
    }
    void setAge(int a) {
        age = a;
    }
    int getAge() {
        return age;
    }
    void setSalary(float s) {
        salary = s;
    }
    float getSalary() {
        return salary;

    }
    void setYears(int y) {
        years_of_experience = y;
    }
    int getYears() {
        return years_of_experience;
    }
};


int main() {

    Employee e;
    e.setName("Omar");
    e.setAge(19);
    e.setSalary(1300.65);
    e.setYears(2);

    cout << "----- Employee Information: -----" << endl;
    cout << "Name: " << e.getName() << endl;
    cout << "Age: " << e.getAge() << endl;
    cout << "Salary: " << e.getSalary() << endl;
    cout << "Years of Experience: " << e.getYears() << endl;

    return 0;
}
